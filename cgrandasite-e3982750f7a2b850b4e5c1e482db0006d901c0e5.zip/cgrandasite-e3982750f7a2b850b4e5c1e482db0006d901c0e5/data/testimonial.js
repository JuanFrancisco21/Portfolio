module.exports = [
  {
    img: "1",
    desc: `Hi, I’m Alvara Atkins and I am designer &amp; developer who dream making the world better place by products. I am also very active for international clients.`,
    name: "Alvara Atkins",
    designation: "Marketing Manager",
    delayAnimation: "",
  },
  {
    img: "2",
    desc: `These people really know what they are doing! Great customer support availability and supperb kindness. I am very happy that I've purchased this liscense!!!`,
    name: "Fabian Gattuzo",
    designation: "Photographer",
    delayAnimation: "100",
  },
  {
    img: "3",
    desc: `These people really know what they are doing! Great customer support availability and supperb kindness. I am very happy that I've purchased this liscense!!!`,
    name: "Alizee Bonita",
    designation: "App Developer",
    delayAnimation: "200",
  },
];
