module.exports = [
  { title: "06", subTitle1: "years of", subTitle2: "Experience" },
  { title: "97", subTitle1: "Completed", subTitle2: "Projects" },
  { title: "81", subTitle1: "Happy", subTitle2: "Customers" },
  { title: "53", subTitle1: "Most awards ", subTitle2: "Winner" },
];
