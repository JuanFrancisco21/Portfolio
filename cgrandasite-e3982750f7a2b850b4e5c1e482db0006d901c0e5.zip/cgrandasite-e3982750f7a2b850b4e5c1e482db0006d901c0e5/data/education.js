module.exports = [
  {
    year: "2015",
    degree: "ENGINEERING DEGREE",
    institute: "OXFORD UNIVERSITY",
    details: `  Lorem ipsum dolor sit amet, consectetur tempor incididunt ut labore
            adipisicing elit`,
  },
  {
    year: "2012",
    degree: "MASTER DEGREE",
    institute: "KIEV UNIVERSITY",
    details: `Lorem incididunt dolor sit amet, consectetur eiusmod dunt doldunt dol
            elit, tempor incididunt`,
  },
  {
    year: "2009",
    degree: "BACHELOR DEGREE ",
    institute: "TUNIS HIGH SCHOOL",
    details: `Lorem ipsum dolor sit amet, tempor incididunt ut laboreconsectetur
            elit, sed do eiusmod tempor duntt`,
  },
];
