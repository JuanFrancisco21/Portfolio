module.exports = [
  {
    year: "2018 - Present",
    position: " Web Developer",
    compnayName: "Envato",
    details: `Lorem ipsum dolor sit amet, consectetur tempor incididunt ut labore
            adipisicing elit`,
  },
  {
    year: "2013 - 2018",
    position: "UI/UX Designer",
    compnayName: "Themeforest",
    details: `Lorem incididunt dolor sit amet, consectetur eiusmod dunt doldunt dol
            elit, tempor incididunt`,
  },
  {
    year: "2005 - 2013",
    position: "Consultant",
    compnayName: "Videohive",
    details: `Lorem ipsum dolor sit amet, tempor incididunt ut laboreconsectetur
            elit, sed do eiusmod tempor duntt`,
  },
];
