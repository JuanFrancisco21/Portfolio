module.exports = [
  { meta: "first name", metaInfo: "Rokers " },
  { meta: "last name", metaInfo: "Nelson" },
  { meta: "Age", metaInfo: "25 Years" },
  { meta: "Nationality", metaInfo: "USA" },
  { meta: "Freelance", metaInfo: "Available" },
  { meta: "Address", metaInfo: "New York" },
  { meta: "phone", metaInfo: "+3456374647" },
  { meta: "Email", metaInfo: "you@mail.com" },
  { meta: "Skype", metaInfo: " rokers.nelson" },
  { meta: "langages", metaInfo: "French, English" },
];
